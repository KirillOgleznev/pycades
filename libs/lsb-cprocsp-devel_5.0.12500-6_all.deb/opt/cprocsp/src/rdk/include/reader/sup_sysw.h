#if !defined( _SUPPORT_SUP_SYSW_H )
#define _SUPPORT_SUP_SYSW_H

#include "reader/support.h"
#include "reader/sup_wnd.h"


#ifdef __cplusplus
extern "C" {
#endif //__cplusplus
#ifndef NO_SUP_PROPERTIES
DWORD supsys_properties(HWND hwnd, const TCHAR* prov_name, TSupSysEContext *ctx);
#endif // !NO_SUP_PROPERTIES

#ifndef NO_SUP_WIZARD
DWORD supsys_add2_item( HWND hwnd, 
    TSupSysEList *list, TSupSysEList *installed_list, 
    TSupSysEContext **context );
#endif // NO_SUP_WIZARD

#ifdef __cplusplus
}
#endif //__cplusplus

#endif /* _SUPPORT_SUP_SYSW_H */
