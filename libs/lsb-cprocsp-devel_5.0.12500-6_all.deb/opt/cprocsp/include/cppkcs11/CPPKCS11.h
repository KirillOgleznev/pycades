#if !defined _CPPKCS11_H_
#define _CPPKCS11_H_
#include "common.h"

#if defined _MSC_VER 
#   pragma pack(push, cryptoki, 1)
#endif 
#include "pkcs11.h"
#if defined _MSC_VER
#   pragma pack(pop, cryptoki)
#endif

#endif	/* _CPPKCS11_H_ */
