#if !defined( _READER_SUPPORT_SUPPORT_HPP )
#define _READER_SUPPORT_SUPPORT_HPP

#ifndef __cplusplus
#error This header should be used only for C++ source files.
#endif //__cplusplus

#include "support.h"
#include "support_locks.hpp"
#include "support_string.hpp"
#include "support_exception.hpp"

#endif //_READER_SUPPORT_SUPPORT_HPP
